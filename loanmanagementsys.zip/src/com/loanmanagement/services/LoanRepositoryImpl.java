package com.loanmanagement.services;

import com.loanmanagement.entity.Loan;
import com.loanmanagement.entity.Customer;
import com.loanmanagement.exception.InvalidLoanException;

import java.util.ArrayList;
import java.util.List;

public class LoanRepositoryImpl implements ILoanRepository {
    private List<Loan> loanDatabase = new ArrayList<>();

    @Override
    public boolean applyLoan(Loan loan) {
        String loanId = "L" + (loanDatabase.size() + 1);
        loan.setLoanId(loanId);
        loan.setRemainingEmis(loan.getLoanTerm());

        loanDatabase.add(loan);
        System.out.println("Loan applied successfully with ID: " + loanId);
        return true;
    }

    @Override
    public double calculateInterest(String loanId) {
        Loan loan = getLoanById(loanId);
        return calculateInterest(loan.getPrincipalAmount(), loan.getInterestRate(), loan.getLoanTerm());
    }

    @Override
    public double calculateInterest(double principalAmount, double interestRate, int loanTenure) {
        return (principalAmount * interestRate * loanTenure) / 12;
    }

    @Override
    public double calculateEMI(String loanId) {
        Loan loan = getLoanById(loanId);
        return calculateEMI(loan.getPrincipalAmount(), loan.getInterestRate(), loan.getLoanTerm());
    }

    @Override
    public double calculateEMI(double principalAmount, double interestRate, int loanTenure) {
        double monthlyInterestRate = interestRate / 12 / 100;
        return (principalAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, loanTenure)) /
                (Math.pow(1 + monthlyInterestRate, loanTenure) - 1);
    }

    @Override
    public List<Loan> getAllLoans() {
        return loanDatabase;
    }

    @Override
    public Loan getLoanById(String loanId) {
        for (Loan loan : loanDatabase) {
            if (loan.getLoanId().equals(loanId)) {
                return loan;
            }
        }
        throw new InvalidLoanException("Loan with ID " + loanId + " not found!");
    }

    @Override
    public void loanRepayment(String loanId, double amount) {
        Loan loan = getLoanById(loanId);
        double emi = calculateEMI(loanId);

        if (loan.getRemainingEmis() <= 0) {
            System.out.println("Loan already fully paid.");
            return;
        }

        if (amount < emi) {
            System.out.println("Payment rejected: Amount is less than one EMI (" + emi + ").");
            return;
        }

        int emisToPay = (int) (amount / emi);
        if (emisToPay > loan.getRemainingEmis()) {
            emisToPay = loan.getRemainingEmis();
        }

        loan.setRemainingEmis(loan.getRemainingEmis() - emisToPay);

        System.out.println("Payment successful. EMIs paid: " + emisToPay +
                ". Remaining EMIs: " + loan.getRemainingEmis());

        if (loan.getRemainingEmis() == 0) {
            loan.setLoanStatus("Paid");
        }
    }
}
