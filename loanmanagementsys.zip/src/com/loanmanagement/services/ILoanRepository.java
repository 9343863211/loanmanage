package com.loanmanagement.services;

import com.loanmanagement.entity.Loan;
import java.util.List;

public interface ILoanRepository {
    boolean applyLoan(Loan loan);
    double calculateInterest(String loanId);
    double calculateInterest(double principalAmount, double interestRate, int loanTenure);
    double calculateEMI(String loanId);
    double calculateEMI(double principalAmount, double interestRate, int loanTenure);
    List<Loan> getAllLoans();
    Loan getLoanById(String loanId);
    void loanRepayment(String loanId, double amount);
}

