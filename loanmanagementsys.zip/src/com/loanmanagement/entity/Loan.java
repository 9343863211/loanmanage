package com.loanmanagement.entity;

public class Loan {
    private String loanId;
    private Customer customer;
    private double principalAmount;
    private double interestRate;
    private int loanTerm; // in months
    private String loanType;
    private String loanStatus;
    private int remainingEmis;

    public Loan(Customer customer, double principalAmount, double interestRate, int loanTerm, String loanType) {
        this.loanId = generateLoanId();
        this.customer = customer;
        this.principalAmount = principalAmount;
        this.interestRate = interestRate;
        this.loanTerm = loanTerm;
        this.loanType = loanType;
        this.loanStatus = "Pending";
        this.remainingEmis = loanTerm;
    }

    private String generateLoanId() {
        int randomNum = (int)(Math.random() * 1000);
        return "LOAN"  + randomNum;
    }

    public String getLoanId() { return loanId; }
    public void setLoanId(String loanId) { this.loanId = loanId; }

    public Customer getCustomer() { return customer; }
    public void setCustomer(Customer customer) { this.customer = customer; }

    public double getPrincipalAmount() { return principalAmount; }
    public void setPrincipalAmount(double principalAmount) { this.principalAmount = principalAmount; }

    public double getInterestRate() { return interestRate; }
    public void setInterestRate(double interestRate) { this.interestRate = interestRate; }

    public int getLoanTerm() { return loanTerm; }
    public void setLoanTerm(int loanTerm) { this.loanTerm = loanTerm; }

    public String getLoanType() { return loanType; }
    public void setLoanType(String loanType) { this.loanType = loanType; }

    public String getLoanStatus() { return loanStatus; }
    public void setLoanStatus(String loanStatus) { this.loanStatus = loanStatus; }

    public int getRemainingEmis() { return remainingEmis; }
    public void setRemainingEmis(int remainingEmis) { this.remainingEmis = remainingEmis; }

    public void printLoanInfo() {
        System.out.println("Loan ID: " + loanId);
        System.out.println("Customer: " + customer.getName());
        System.out.println("Loan Type: " + loanType);
        System.out.println("Principal Amount: " + principalAmount);
        System.out.println("Interest Rate: " + interestRate);
        System.out.println("Loan Term (Months): " + loanTerm);
        System.out.println("Remaining EMIs: " + remainingEmis);
        System.out.println("Loan Status: " + loanStatus);
    }
}
