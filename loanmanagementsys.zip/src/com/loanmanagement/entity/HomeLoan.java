package com.loanmanagement.entity;

public class HomeLoan extends Loan {
    private double downPayment;
    private String propertyType;

    public HomeLoan(Customer customer, double principalAmount, double interestRate, int loanTerm,
                    double downPayment, String propertyType) {
        super(customer, principalAmount, interestRate, loanTerm, "HomeLoan");
        this.downPayment = downPayment;
        this.propertyType = propertyType;
    }

    public double getDownPayment() { return downPayment; }
    public void setDownPayment(double downPayment) { this.downPayment = downPayment; }

    public String getPropertyType() { return propertyType; }
    public void setPropertyType(String propertyType) { this.propertyType = propertyType; }


    public void printHomeLoanDetails() {
        super.printLoanInfo();
        System.out.println("Down Payment: " + downPayment);
        System.out.println("Property Type: " + propertyType);
    }
}
