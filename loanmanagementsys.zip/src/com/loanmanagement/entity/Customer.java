package com.loanmanagement.entity;

public class Customer {
    private String customerId;
    private String name;
    private int creditScore;

    public Customer(String name, int creditScore) {
        this.customerId = generateCustomerId();
        this.name = name;
        this.creditScore = creditScore;
    }

    private String generateCustomerId() {
        long timestamp = System.currentTimeMillis();
        int random = (int)(Math.random() * 1000);
        return "CUST" + timestamp + random;
    }

    public String getCustomerId() { return customerId; }
    public String getName() { return name; }
    public int getCreditScore() { return creditScore; }

    public void setName(String name) { this.name = name; }
    public void setCreditScore(int creditScore) { this.creditScore = creditScore; }
}
