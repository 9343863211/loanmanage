package com.loanmanagement.entity;

public class CarLoan extends Loan {
    private String carMake;
    private String carModel;

    public CarLoan(Customer customer, double principalAmount, double interestRate, int loanTerm,
                   String carMake, String carModel) {
        super(customer, principalAmount, interestRate, loanTerm, "CarLoan");
        this.carMake = carMake;
        this.carModel = carModel;
    }


    public String getCarMake() { return carMake; }
    public void setCarMake(String carMake) { this.carMake = carMake; }

    public String getCarModel() { return carModel; }
    public void setCarModel(String carModel) { this.carModel = carModel; }


    public void printCarLoanDetails() {
        super.printLoanInfo();
        System.out.println("Car Make: " + carMake);
        System.out.println("Car Model: " + carModel);
    }
}
