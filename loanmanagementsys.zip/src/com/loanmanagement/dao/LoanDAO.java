package com.loanmanagement.dao;

public class LoanDAO {
}
