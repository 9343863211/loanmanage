package com.loanmanagement.util;

import java.util.HashMap;
import java.util.Map;

public class CreditScoreValidator {
    private static final Map<String, Integer> loanThresholds = new HashMap<>();

    static {
        loanThresholds.put("HomeLoan", 750);
        loanThresholds.put("CarLoan", 700);
        loanThresholds.put("PersonalLoan", 650);
    }

    public static boolean isEligible(String loanType, int creditScore) {
        return creditScore >= loanThresholds.getOrDefault(loanType, 650);
    }

    public static int getMinimumCreditScore(String loanType) {
        return loanThresholds.getOrDefault(loanType, 650);
    }
}

