package com.loanmanagement.main;

import com.loanmanagement.entity.Customer;
import com.loanmanagement.entity.Loan;
import com.loanmanagement.services.LoanRepositoryImpl;
import com.loanmanagement.services.ILoanRepository;
import com.loanmanagement.util.CreditScoreValidator;

import java.util.List;
import java.util.Scanner;

public class LoanManagement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ILoanRepository loanRepo = new LoanRepositoryImpl();

        while (true) {
            String loanId = null;

            System.out.println("1. Apply for loan");
            System.out.println("2. View All loans");
            System.out.println("3. Calculate interest");
            System.out.println("4. Calculate your EMI");
            System.out.println("5. Get your loan details by loan ID");
            System.out.println("6. Make loan repayment");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter customer name: ");
                    String name = scanner.next();
                    System.out.print("Enter credit score: ");
                    int creditScore = scanner.nextInt();

                    Customer customer = new Customer(name, creditScore);
                    System.out.print("Enter principal amount: ");
                    double principalAmount = scanner.nextDouble();
                    System.out.print("Enter loan tenure (months): ");
                    int loanTerm = scanner.nextInt();
                    System.out.print("Enter loan type (e.g., HomeLoan, CarLoan): ");
                    String loanType = scanner.next();

                    if (!CreditScoreValidator.isEligible(loanType, creditScore)) {
                        System.out.println("Loan application denied: Minimum credit score required for "
                                + loanType + " is " + CreditScoreValidator.getMinimumCreditScore(loanType));
                        break;
                    }

                    double interestRate;
                    if (loanType.equalsIgnoreCase("HomeLoan")) {
                        interestRate = 8.5;
                    } else if (loanType.equalsIgnoreCase("CarLoan")) {
                        interestRate = 9.5;
                    } else {
                        interestRate = 10.0;
                    }
                    System.out.println("Interest rate set to " + interestRate + "% for " + loanType);

                    Loan loan = new Loan(customer, principalAmount, interestRate, loanTerm, loanType);
                    loanRepo.applyLoan(loan);
                    break;

                case 2:
                    List<Loan> allLoans = loanRepo.getAllLoans();
                    if (allLoans.isEmpty()) {
                        System.out.println("No loans found.");
                    } else {
                        for (Loan l : allLoans) {
                            l.printLoanInfo();
                            System.out.println("--------------");
                        }
                    }
                    break;

                case 3:
                    System.out.print("Enter loan ID: ");
                    loanId = scanner.next();
                    try {
                        double interest = loanRepo.calculateInterest(loanId);
                        System.out.println("Loan interest: " + interest);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 4:
                    System.out.print("Enter loan ID: ");
                    loanId = scanner.next();
                    try {
                        double emi = loanRepo.calculateEMI(loanId);
                        System.out.println("EMI: " + emi);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 5:
                    System.out.print("Enter loan ID: ");
                    loanId = scanner.next();
                    try {
                        Loan l = loanRepo.getLoanById(loanId);
                        l.printLoanInfo();
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 6:
                    System.out.print("Enter loan ID: ");
                    loanId = scanner.next();
                    System.out.print("Enter repayment amount: ");
                    double amount = scanner.nextDouble();
                    try {
                        loanRepo.loanRepayment(loanId, amount);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 7:
                    System.out.println("Exiting...");
                    System.exit(0);

                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }
}
